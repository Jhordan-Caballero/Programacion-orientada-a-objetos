/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.proyecto_base_de_datos;

/**
 *
 * @author jcaba
 */
public class Proyecto_Base_de_datos {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
